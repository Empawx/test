--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

-- Started on 2025-06-19 23:54:23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 230 (class 1259 OID 34832)
-- Name: Customers; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo."Customers" (
    "CustomerID" integer NOT NULL,
    "Name" character varying(100)[],
    "ContactInfo" character varying(255)[]
);


ALTER TABLE demo."Customers" OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 34819)
-- Name: material_type; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.material_type (
    materialtype_id integer NOT NULL,
    materialtype_name character varying(50) NOT NULL,
    scrap_rate numeric NOT NULL
);


ALTER TABLE demo.material_type OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 34824)
-- Name: material_type_materialtype_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.material_type_materialtype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.material_type_materialtype_id_seq OWNER TO postgres;

--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 229
-- Name: material_type_materialtype_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.material_type_materialtype_id_seq OWNED BY demo.material_type.materialtype_id;


--
-- TOC entry 218 (class 1259 OID 34758)
-- Name: operation_history; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.operation_history (
    operation_id integer NOT NULL,
    operation_product integer NOT NULL,
    operation_partner integer NOT NULL,
    product_count integer NOT NULL,
    operation_date timestamp without time zone NOT NULL
);


ALTER TABLE demo.operation_history OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 34761)
-- Name: operation_history_operation_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.operation_history_operation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.operation_history_operation_id_seq OWNER TO postgres;

--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 219
-- Name: operation_history_operation_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.operation_history_operation_id_seq OWNED BY demo.operation_history.operation_id;


--
-- TOC entry 220 (class 1259 OID 34762)
-- Name: partner_type; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.partner_type (
    partnertype_id integer NOT NULL,
    type_name character varying(50) NOT NULL
);


ALTER TABLE demo.partner_type OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 34765)
-- Name: partner_type_partnertype_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.partner_type_partnertype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.partner_type_partnertype_id_seq OWNER TO postgres;

--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 221
-- Name: partner_type_partnertype_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.partner_type_partnertype_id_seq OWNED BY demo.partner_type.partnertype_id;


--
-- TOC entry 222 (class 1259 OID 34766)
-- Name: partners; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.partners (
    partner_id integer NOT NULL,
    partner_name character varying(250) NOT NULL,
    partner_type integer NOT NULL,
    partner_director character varying(100) NOT NULL,
    partner_email character varying(50) NOT NULL,
    partner_phone character varying(50) NOT NULL,
    partner_address character varying(250) NOT NULL,
    partner_inn character varying(50) NOT NULL,
    partner_rating numeric NOT NULL
);


ALTER TABLE demo.partners OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 34771)
-- Name: partners_partner_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.partners_partner_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.partners_partner_id_seq OWNER TO postgres;

--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 223
-- Name: partners_partner_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.partners_partner_id_seq OWNED BY demo.partners.partner_id;


--
-- TOC entry 224 (class 1259 OID 34772)
-- Name: product_type; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.product_type (
    producttype_id integer NOT NULL,
    type_name character varying(50) NOT NULL,
    type_coefficient numeric NOT NULL
);


ALTER TABLE demo.product_type OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 34777)
-- Name: product_type_type_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.product_type_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.product_type_type_id_seq OWNER TO postgres;

--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 225
-- Name: product_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.product_type_type_id_seq OWNED BY demo.product_type.producttype_id;


--
-- TOC entry 226 (class 1259 OID 34778)
-- Name: products; Type: TABLE; Schema: demo; Owner: postgres
--

CREATE TABLE demo.products (
    product_id integer NOT NULL,
    product_name character varying(250) NOT NULL,
    product_type integer NOT NULL,
    minimal_price numeric NOT NULL,
    material_type integer,
    "Code" character varying(255)[],
    "Brand" character varying(100)[],
    "Category" character varying(100)[],
    "Image" character varying(255)[]
);


ALTER TABLE demo.products OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 34783)
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: demo; Owner: postgres
--

CREATE SEQUENCE demo.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo.products_product_id_seq OWNER TO postgres;

--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 227
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: demo; Owner: postgres
--

ALTER SEQUENCE demo.products_product_id_seq OWNED BY demo.products.product_id;


--
-- TOC entry 4664 (class 2604 OID 34784)
-- Name: operation_history operation_id; Type: DEFAULT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.operation_history ALTER COLUMN operation_id SET DEFAULT nextval('demo.operation_history_operation_id_seq'::regclass);


--
-- TOC entry 4665 (class 2604 OID 34785)
-- Name: partner_type partnertype_id; Type: DEFAULT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.partner_type ALTER COLUMN partnertype_id SET DEFAULT nextval('demo.partner_type_partnertype_id_seq'::regclass);


--
-- TOC entry 4666 (class 2604 OID 34786)
-- Name: partners partner_id; Type: DEFAULT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.partners ALTER COLUMN partner_id SET DEFAULT nextval('demo.partners_partner_id_seq'::regclass);


--
-- TOC entry 4667 (class 2604 OID 34787)
-- Name: product_type producttype_id; Type: DEFAULT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.product_type ALTER COLUMN producttype_id SET DEFAULT nextval('demo.product_type_type_id_seq'::regclass);


--
-- TOC entry 4668 (class 2604 OID 34788)
-- Name: products product_id; Type: DEFAULT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.products ALTER COLUMN product_id SET DEFAULT nextval('demo.products_product_id_seq'::regclass);


--
-- TOC entry 4845 (class 0 OID 34832)
-- Dependencies: 230
-- Data for Name: Customers; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo."Customers" ("CustomerID", "Name", "ContactInfo") FROM stdin;
\.


--
-- TOC entry 4843 (class 0 OID 34819)
-- Dependencies: 228
-- Data for Name: material_type; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.material_type (materialtype_id, materialtype_name, scrap_rate) FROM stdin;
1	пробковый дуб	7
2	дуб1	8
3	дуб2	8
4	ясень	6
5	дуб3	6
\.


--
-- TOC entry 4833 (class 0 OID 34758)
-- Dependencies: 218
-- Data for Name: operation_history; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.operation_history (operation_id, operation_product, operation_partner, product_count, operation_date) FROM stdin;
1	8758385	1	15500	2023-03-23 00:00:00
2	7750282	1	12350	2023-12-18 00:00:00
3	7028748	1	37400	2024-06-07 00:00:00
4	8858958	2	35000	2022-12-02 00:00:00
5	5012543	2	1250	2023-05-17 00:00:00
6	7750282	2	1000	2024-06-07 00:00:00
7	8758385	2	7550	2024-07-01 00:00:00
8	8758385	3	7250	2023-01-22 00:00:00
9	8858958	3	2500	2024-07-05 00:00:00
10	7028748	4	59050	2023-03-20 00:00:00
11	7750282	4	37200	2024-03-12 00:00:00
12	5012543	4	4500	2024-05-14 00:00:00
13	7750282	5	50000	2023-09-19 00:00:00
14	7028748	5	670000	2023-11-10 00:00:00
15	8758385	5	35000	2024-04-15 00:00:00
16	8858958	5	25000	2024-06-12 00:00:00
\.


--
-- TOC entry 4835 (class 0 OID 34762)
-- Dependencies: 220
-- Data for Name: partner_type; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.partner_type (partnertype_id, type_name) FROM stdin;
1	ЗАО
2	ООО
3	ПАО
4	ОАО
\.


--
-- TOC entry 4837 (class 0 OID 34766)
-- Dependencies: 222
-- Data for Name: partners; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.partners (partner_id, partner_name, partner_type, partner_director, partner_email, partner_phone, partner_address, partner_inn, partner_rating) FROM stdin;
1	База Строитель	1	Иванова Александра Ивановна	aleksandraivanova@ml.ru	493 123 45 67	652050, Кемеровская область, город Юрга, ул. Лесная, 15	2222455179	7
2	Паркет 29	2	Петров Василий Петрович	vppetrov@vl.ru	987 123 56 78	164500, Архангельская область, город Северодвинск, ул. Строителей, 18	3333888520	7
3	Стройсервис	3	Соловьев Андрей Николаевич	ansolovev@st.ru	812 223 32 00	188910, Ленинградская область, город Приморск, ул. Парковая, 21	4440391035	7
4	Ремонт и отделка	4	Воробьева Екатерина Валерьевна	ekaterina.vorobeva@ml.ru	444 222 33 11	143960, Московская область, город Реутов, ул. Свободы, 51	1111520857	5
5	МонтажПро	1	Степанов Степан Сергеевич	stepanov@stepan.ru	912 888 33 33	309500, Белгородская область, город Старый Оскол, ул. Рабочая, 122	5552431140	10
6	СтройМат	2	Петров Алексей Сергеевич	alekseii@gmail.com	497 123 45 67	127410, Московская область, город Москва, ул. Лесная, 15		3
7	База_строй	4	Иванова Сергей Васильевич	gfgfgfgfgfgfgfgfgfg@ml.ru	493 987 65 43	652050, Кемеровская область,  город Юрга, ул. Лесная д. 18		10
\.


--
-- TOC entry 4839 (class 0 OID 34772)
-- Dependencies: 224
-- Data for Name: product_type; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.product_type (producttype_id, type_name, type_coefficient) FROM stdin;
1	Ламинат	2.35
2	Массивная доска	5.15
3	Паркетная доска	4.34
4	Пробковое покрытие	1.5
\.


--
-- TOC entry 4841 (class 0 OID 34778)
-- Dependencies: 226
-- Data for Name: products; Type: TABLE DATA; Schema: demo; Owner: postgres
--

COPY demo.products (product_id, product_name, product_type, minimal_price, material_type, "Code", "Brand", "Category", "Image") FROM stdin;
5012543	Пробковое напольное клеевое покрытие 32 класс 4 мм	4	5450.59	1	\N	\N	\N	\N
7028748	Ламинат Дуб серый 32 класс 8 мм с фаской	1	3890.41	2	\N	\N	\N	\N
7750282	Ламинат Дуб дымчато-белый 33 класс 12 мм	1	1799.33	3	\N	\N	\N	\N
8758385	Паркетная доска Ясень темный однополосная 14 мм	3	4456.90	4	\N	\N	\N	\N
8858958	Инженерная доска Дуб Французская елка однополосная 12 мм	3	7330.99	5	\N	\N	\N	\N
\.


--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 229
-- Name: material_type_materialtype_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.material_type_materialtype_id_seq', 1, false);


--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 219
-- Name: operation_history_operation_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.operation_history_operation_id_seq', 16, true);


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 221
-- Name: partner_type_partnertype_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.partner_type_partnertype_id_seq', 4, true);


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 223
-- Name: partners_partner_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.partners_partner_id_seq', 7, true);


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 225
-- Name: product_type_type_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.product_type_type_id_seq', 4, true);


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 227
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: demo; Owner: postgres
--

SELECT pg_catalog.setval('demo.products_product_id_seq', 1, false);


--
-- TOC entry 4682 (class 2606 OID 34838)
-- Name: Customers Customers_pkey; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo."Customers"
    ADD CONSTRAINT "Customers_pkey" PRIMARY KEY ("CustomerID");


--
-- TOC entry 4680 (class 2606 OID 34826)
-- Name: material_type material_type_pkey; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.material_type
    ADD CONSTRAINT material_type_pkey PRIMARY KEY (materialtype_id);


--
-- TOC entry 4670 (class 2606 OID 34790)
-- Name: operation_history operation_history_pk; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.operation_history
    ADD CONSTRAINT operation_history_pk PRIMARY KEY (operation_id);


--
-- TOC entry 4672 (class 2606 OID 34792)
-- Name: partner_type partner_type_pk; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.partner_type
    ADD CONSTRAINT partner_type_pk PRIMARY KEY (partnertype_id);


--
-- TOC entry 4674 (class 2606 OID 34794)
-- Name: partners partners_pk; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.partners
    ADD CONSTRAINT partners_pk PRIMARY KEY (partner_id);


--
-- TOC entry 4676 (class 2606 OID 34796)
-- Name: product_type product_type_pk; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.product_type
    ADD CONSTRAINT product_type_pk PRIMARY KEY (producttype_id);


--
-- TOC entry 4678 (class 2606 OID 34798)
-- Name: products products_pk; Type: CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.products
    ADD CONSTRAINT products_pk PRIMARY KEY (product_id);


--
-- TOC entry 4683 (class 2606 OID 34799)
-- Name: operation_history operation_history_partners_fk; Type: FK CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.operation_history
    ADD CONSTRAINT operation_history_partners_fk FOREIGN KEY (operation_partner) REFERENCES demo.partners(partner_id);


--
-- TOC entry 4684 (class 2606 OID 34804)
-- Name: operation_history operation_history_products_fk; Type: FK CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.operation_history
    ADD CONSTRAINT operation_history_products_fk FOREIGN KEY (operation_product) REFERENCES demo.products(product_id);


--
-- TOC entry 4685 (class 2606 OID 34809)
-- Name: partners partners_partner_type_fk; Type: FK CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.partners
    ADD CONSTRAINT partners_partner_type_fk FOREIGN KEY (partner_type) REFERENCES demo.partner_type(partnertype_id);


--
-- TOC entry 4686 (class 2606 OID 34827)
-- Name: products products_material_type_fk; Type: FK CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.products
    ADD CONSTRAINT products_material_type_fk FOREIGN KEY (material_type) REFERENCES demo.material_type(materialtype_id);


--
-- TOC entry 4687 (class 2606 OID 34814)
-- Name: products products_product_type_fk; Type: FK CONSTRAINT; Schema: demo; Owner: postgres
--

ALTER TABLE ONLY demo.products
    ADD CONSTRAINT products_product_type_fk FOREIGN KEY (product_type) REFERENCES demo.product_type(producttype_id);


-- Completed on 2025-06-19 23:54:23

--
-- PostgreSQL database dump complete
--

