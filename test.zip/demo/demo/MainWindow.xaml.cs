﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Partners P = new Partners();
        public Changing C = new Changing();
        public Operations O = new Operations();

        public MainWindow()
        {
            
            InitializeComponent();
            MainFrame.Content = P;
            LoadData();
            
        }
        public void LoadData()
        {
            Console.WriteLine("dsfsfs");
        }

        private void ButtonPartners_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = P;
            PartnersBut.Background = new SolidColorBrush(Color.FromRgb(103, 186, 128));
            OperationBut.Background= new SolidColorBrush(Color.FromRgb(221, 221, 221));
            ChangingBut.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
        }

        private void ButtonChanging_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = C;
            PartnersBut.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            OperationBut.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            ChangingBut.Background = new SolidColorBrush(Color.FromRgb(103, 186, 128));
        }

        private void ButtonOperations_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = O;
            PartnersBut.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            OperationBut.Background = new SolidColorBrush(Color.FromRgb(103, 186, 128));
            ChangingBut.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
        }
    }
}