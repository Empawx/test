﻿using demo.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demo
{
    /// <summary>
    /// Логика взаимодействия для Operations.xaml
    /// </summary>
    public partial class Operations : Page
    {
        public MyDbContext context = new MyDbContext();
        public Operations()
        {
            InitializeComponent();
            LoadData();
        }
        public void LoadData()
        {

            var operationsList = context.OperationHistories.Include(o=>o.OperationPartnerNavigation)
                .Include(o=>o.OperationProductNavigation)
                .Select(p => new OperationsInfo
                {
                    OperationId = p.OperationId,
                    ProductName = p.OperationProductNavigation.ProductName,
                    PartnerName = p.OperationPartnerNavigation.PartnerName,
                    ProductCount = p.ProductCount,
                    OperationDate = p.OperationDate,
                   
                }).ToList();
            MyListView.ItemsSource = operationsList;
        }
        private void MyListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(MyListView.SelectedItem is OperationsInfo OI)
            {
                ProductNameTB.Text = OI.ProductName;
                PartnerNameTB.Text = OI.PartnerName;
                ProductCountTB.Text =Convert.ToString(OI.ProductCount);
                OperationDateTB.Text = Convert.ToString(OI.OperationDate);
                var prodtypeid = context.OperationHistories
                    .Include(oh => oh.OperationProductNavigation)
                    .Where(oh=>oh.OperationId==OI.OperationId)
                    .Select(oh=>oh.OperationProductNavigation.ProductType)
                    .FirstOrDefault();
                var mattypeid = context.OperationHistories
                     .Include(oh => oh.OperationProductNavigation)
                     .Where(oh => oh.OperationId == OI.OperationId)
                     .Select(oh => oh.OperationProductNavigation.MaterialType)
                     .FirstOrDefault();
                MatCountTB.Text= Convert.ToString(MaterialsMetod(prodtypeid, mattypeid,OI.ProductCount));
            }
        }
        private long MaterialsMetod(int prodtypeid, int mattypeid, int prodcount)
        {
            var prodTypeC = context.ProductTypes
                .FirstOrDefault(pt => pt.ProducttypeId == prodtypeid)?.TypeCoefficient ?? 0m;

            var prodmatScrap = context.MaterialTypes
                .FirstOrDefault(mt => mt.MaterialtypeId == mattypeid)?.ScrapRate ?? 0m;

            decimal matCount = Math.Round((prodcount * prodTypeC) * prodmatScrap * prodcount);

            if (matCount > long.MaxValue || matCount < long.MinValue)
                throw new OverflowException($"Значение {matCount} выходит за пределы Int64.");

            return (long)matCount;
        }

    }
    public class OperationsInfo
    {
        public int OperationId { get; set; }
        public string ProductName { get; set; }
        public string PartnerName { get; set; }
        public int ProductCount { get; set; }
        public DateTime OperationDate { get; set; }
        
    }
}
