﻿using demo.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace demo
{
    /// <summary>
    /// Логика взаимодействия для Partners.xaml
    /// </summary>
    public partial class Partners : Page
    {
        public ObservableCollection<PartnerP> Partners1 {  get; set; }
        public Partners()
        {
            InitializeComponent();
            DataContext = this;
            LoadData();
        }
        public void LoadData()
        {
            using (var context = new MyDbContext())
            {
                Partners1 = new ObservableCollection<PartnerP>(
                context.Partners
                    .Include(p => p.PartnerTypeNavigation)
                    .Include(p => p.OperationHistories)
                    .Select(p => new PartnerP
                    {
                        TypeName = p.PartnerTypeNavigation.TypeName,
                        PartnerName = p.PartnerName,
                        PartnerPhone = p.PartnerPhone,
                        PartnerRating = p.PartnerRating,
                        Discount = 
                        p.OperationHistories.Sum(oh => oh.ProductCount) >= 300000 ? 15 :
                        p.OperationHistories.Sum(oh => oh.ProductCount) >= 50000 ? 10 :
                        p.OperationHistories.Sum(oh => oh.ProductCount) >= 10000 ? 5 : 0

                    })
                    .ToList());
                
            }
            Debug.WriteLine(Partners1);
        }
    }



    public class PartnerP
    {
        public string TypeName { get; set; }
        public string PartnerName { get; set; }
        public string PartnerPhone { get; set; }
        public int PartnerRating { get; set; }
       
        public int Discount { get; set; }

    }

}
