﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class Product
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public int ProductType { get; set; }

    public decimal MinimalPrice { get; set; }

    public int MaterialType { get; set; }

    public virtual MaterialType MaterialTypeNavigation { get; set; } = null!;

    public virtual ICollection<OperationHistory> OperationHistories { get; set; } = new List<OperationHistory>();

    public virtual ProductType ProductTypeNavigation { get; set; } = null!;
}
