﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class Partner
{
    public int PartnerId { get; set; }

    public string PartnerName { get; set; } = null!;

    public int PartnerType { get; set; }

    public string PartnerDirector { get; set; } = null!;

    public string PartnerEmail { get; set; } = null!;

    public string PartnerPhone { get; set; } = null!;

    public string PartnerAddress { get; set; } = null!;

    public string PartnerInn { get; set; } = null!;

    public int PartnerRating { get; set; }

    public virtual ICollection<OperationHistory> OperationHistories { get; set; } = new List<OperationHistory>();

    public virtual PartnerType PartnerTypeNavigation { get; set; } = null!;
}
