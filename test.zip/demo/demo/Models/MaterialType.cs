﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class MaterialType
{
    public int MaterialtypeId { get; set; }

    public string MaterialtypeName { get; set; } = null!;

    public decimal ScrapRate { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
