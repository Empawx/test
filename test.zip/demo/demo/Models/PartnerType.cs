﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class PartnerType
{
    public int PartnertypeId { get; set; }

    public string TypeName { get; set; } = null!;

    public virtual ICollection<Partner> Partners { get; set; } = new List<Partner>();
}
