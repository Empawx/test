﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace demo.Models;

public partial class MyDbContext : DbContext
{
    public MyDbContext()
    {
    }

    public MyDbContext(DbContextOptions<MyDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<MaterialType> MaterialTypes { get; set; }

    public virtual DbSet<OperationHistory> OperationHistories { get; set; }

    public virtual DbSet<Partner> Partners { get; set; }

    public virtual DbSet<PartnerType> PartnerTypes { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("Host=localhost;Database=demo;Username=postgres;Password=11111111");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MaterialType>(entity =>
        {
            entity.HasKey(e => e.MaterialtypeId).HasName("material_type_pk");

            entity.ToTable("material_type", "demo");

            entity.Property(e => e.MaterialtypeId).HasColumnName("materialtype_id");
            entity.Property(e => e.MaterialtypeName)
                .HasMaxLength(50)
                .HasColumnName("materialtype_name");
            entity.Property(e => e.ScrapRate).HasColumnName("scrap_rate");
        });

        modelBuilder.Entity<OperationHistory>(entity =>
        {
            entity.HasKey(e => e.OperationId).HasName("operation_history_pk");

            entity.ToTable("operation_history", "demo");

            entity.Property(e => e.OperationId).HasColumnName("operation_id");
            entity.Property(e => e.OperationDate)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("operation_date");
            entity.Property(e => e.OperationPartner).HasColumnName("operation_partner");
            entity.Property(e => e.OperationProduct).HasColumnName("operation_product");
            entity.Property(e => e.ProductCount).HasColumnName("product_count");

            entity.HasOne(d => d.OperationPartnerNavigation).WithMany(p => p.OperationHistories)
                .HasForeignKey(d => d.OperationPartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("operation_history_partners_fk");

            entity.HasOne(d => d.OperationProductNavigation).WithMany(p => p.OperationHistories)
                .HasForeignKey(d => d.OperationProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("operation_history_products_fk");
        });

        modelBuilder.Entity<Partner>(entity =>
        {
            entity.HasKey(e => e.PartnerId).HasName("partners_pk");

            entity.ToTable("partners", "demo");

            entity.Property(e => e.PartnerId).HasColumnName("partner_id");
            entity.Property(e => e.PartnerAddress)
                .HasMaxLength(250)
                .HasColumnName("partner_address");
            entity.Property(e => e.PartnerDirector)
                .HasMaxLength(100)
                .HasColumnName("partner_director");
            entity.Property(e => e.PartnerEmail)
                .HasMaxLength(50)
                .HasColumnName("partner_email");
            entity.Property(e => e.PartnerInn)
                .HasMaxLength(50)
                .HasColumnName("partner_inn");
            entity.Property(e => e.PartnerName)
                .HasMaxLength(250)
                .HasColumnName("partner_name");
            entity.Property(e => e.PartnerPhone)
                .HasMaxLength(50)
                .HasColumnName("partner_phone");
            entity.Property(e => e.PartnerRating).HasColumnName("partner_rating");
            entity.Property(e => e.PartnerType).HasColumnName("partner_type");

            entity.HasOne(d => d.PartnerTypeNavigation).WithMany(p => p.Partners)
                .HasForeignKey(d => d.PartnerType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("partners_partner_type_fk");
        });

        modelBuilder.Entity<PartnerType>(entity =>
        {
            entity.HasKey(e => e.PartnertypeId).HasName("partner_type_pk");

            entity.ToTable("partner_type", "demo");

            entity.Property(e => e.PartnertypeId).HasColumnName("partnertype_id");
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .HasColumnName("type_name");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("products_pk");

            entity.ToTable("products", "demo");

            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.MaterialType).HasColumnName("material_type");
            entity.Property(e => e.MinimalPrice).HasColumnName("minimal_price");
            entity.Property(e => e.ProductName)
                .HasMaxLength(250)
                .HasColumnName("product_name");
            entity.Property(e => e.ProductType).HasColumnName("product_type");

            entity.HasOne(d => d.MaterialTypeNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.MaterialType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("products_material_type_fk");

            entity.HasOne(d => d.ProductTypeNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.ProductType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("products_product_type_fk");
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.HasKey(e => e.ProducttypeId).HasName("product_type_pk");

            entity.ToTable("product_type", "demo");

            entity.Property(e => e.ProducttypeId)
                .HasDefaultValueSql("nextval('demo.product_type_type_id_seq'::regclass)")
                .HasColumnName("producttype_id");
            entity.Property(e => e.TypeCoefficient).HasColumnName("type_coefficient");
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .HasColumnName("type_name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
