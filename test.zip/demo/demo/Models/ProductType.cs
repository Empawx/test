﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class ProductType
{
    public int ProducttypeId { get; set; }

    public string TypeName { get; set; } = null!;

    public decimal TypeCoefficient { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
