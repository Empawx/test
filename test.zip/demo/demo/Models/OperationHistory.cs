﻿using System;
using System.Collections.Generic;

namespace demo.Models;

public partial class OperationHistory
{
    public int OperationId { get; set; }

    public int OperationProduct { get; set; }

    public int OperationPartner { get; set; }

    public int ProductCount { get; set; }

    public DateTime OperationDate { get; set; }

    public virtual Partner OperationPartnerNavigation { get; set; } = null!;

    public virtual Product OperationProductNavigation { get; set; } = null!;
}
