﻿using demo.Models;
using Microsoft.EntityFrameworkCore;
using Npgsql.Internal.Postgres;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demo
{
    /// <summary>
    /// Логика взаимодействия для Changing.xaml
    /// </summary>
    public partial class Changing : Page
    {
        public MyDbContext context = new MyDbContext(); 
        public Changing()
        {
            InitializeComponent();
            LoadData();
            
        }
        public void LoadData()
        {
           
            var partnersList = context.Partners.Include(p=>p.PartnerTypeNavigation)
                .Select(p=> new PartnersInfo { 
                PartnerId=p.PartnerId,
                PartnerName=p.PartnerName,
                PartnerType=p.PartnerTypeNavigation.TypeName,
                PartnerRating= p.PartnerRating,
                PartnerAddress= p.PartnerAddress,
                PartnerDirector = p.PartnerDirector,
                PartnerPhone = p.PartnerPhone,
                PartnerEmail = p.PartnerEmail
                
                }).ToList();
            MyListView.ItemsSource = partnersList;
        }

        private void RadioChange_Checked(object sender, RoutedEventArgs e)
        {
            MyListView.IsEnabled = true;
            ChangeBut.IsEnabled = true;
            AddBut.IsEnabled = false;
        }

        private void RadioAdd_Checked(object sender, RoutedEventArgs e)
        {
            MyListView.IsEnabled = false;
            ChangeBut.IsEnabled = false;
            AddBut.IsEnabled = true;
        }

        private void MyListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(MyListView.SelectedItem is PartnersInfo PI)
            {
                PartnerNameTB.Text = PI.PartnerName;
                PartnerTypeCB.Text = PI.PartnerType;
                PartnerRatingTB.Text = Convert.ToString(PI.PartnerRating);
                PartnerAddressTB.Text = PI.PartnerAddress;
                PartnerDirectorTB.Text += PI.PartnerDirector;
                PartnerPhoneTB.Text = PI.PartnerPhone;
                PartnerEmailTB.Text = PI.PartnerEmail;
            }
        }

        private void AddBut_Click(object sender, RoutedEventArgs e)
        {
            
            
            if (context.Partners.FirstOrDefault(p => p.PartnerName == PartnerNameTB.Text) == null)
            {
                var typeId = context.PartnerTypes.FirstOrDefault(p => p.TypeName == PartnerTypeCB.Text).PartnertypeId;
                Partner PI = new Partner
                {
                    PartnerName = PartnerNameTB.Text,
                    PartnerType = typeId,
                    PartnerRating = Convert.ToInt32(PartnerRatingTB.Text),
                    PartnerDirector = PartnerDirectorTB.Text,
                    PartnerAddress = PartnerAddressTB.Text,
                    PartnerPhone = PartnerPhoneTB.Text,
                    PartnerEmail = PartnerEmailTB.Text,
                    PartnerInn = ""
                };
                context.Partners.Add(PI);
                context.SaveChanges();
            }
            else MessageBox.Show("Такой партнер уже существует", "Ошибка");
            LoadData();
        }

        private void ChangeBut_Click(object sender, RoutedEventArgs e)
        {
            var partn = context.Partners.FirstOrDefault(p => p.PartnerName == PartnerNameTB.Text);
            if (partn != null)
            {
                var typeId = context.PartnerTypes.FirstOrDefault(p => p.TypeName == PartnerTypeCB.Text).PartnertypeId;
                partn.PartnerName = PartnerNameTB.Text;
                partn.PartnerType = typeId;
                partn.PartnerRating = Convert.ToInt32(PartnerRatingTB.Text);
                partn.PartnerDirector = PartnerDirectorTB.Text;
                partn.PartnerAddress = PartnerAddressTB.Text;
                partn.PartnerPhone = PartnerPhoneTB.Text;
                partn.PartnerEmail = PartnerEmailTB.Text;
                context.SaveChanges();
                LoadData();
            }
            else MessageBox.Show("Такого партнера не существует", "Ошибка");
        }
    }
    public class PartnersInfo
    {
        public int PartnerId {  get; set; }
        public string PartnerName { get; set; }
        public string PartnerType { get; set; }
        public int PartnerRating { get; set; }
        public string PartnerAddress {  get; set; }
        public string PartnerDirector { get; set; }
        public string PartnerPhone { get; set; }
        public string PartnerEmail { get; set; }
    }
}
